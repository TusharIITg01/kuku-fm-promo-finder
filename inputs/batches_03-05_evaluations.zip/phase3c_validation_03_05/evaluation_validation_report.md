# Evaluation Validation Report

- Imported batch(es): batch_03, batch_04, batch_05
- Evaluations received: 30
- Valid evaluations: 30
- PASS / REJECT: 17 / 13 (valid records)
- Duplicate candidate IDs: 0
- Unknown candidate IDs: 0
- immediate_resolution is descriptive only; it is not an automatic rejection gate.

| Candidate | Decision | Immediate resolution | Weighted score | Validation |
|---|---:|---:|---:|---|
| C006-03 | REJECT | False | 2.6 | VALID |
| C006-04 | REJECT | False | 2.1 | VALID |
| C007-01 | REJECT | False | 2.35 | VALID |
| C007-02 | PASS | True | 3.5 | VALID |
| C007-03 | PASS | True | 4.25 | VALID |
| C007-04 | REJECT | True | 3.1 | VALID |
| C008-01 | REJECT | False | 2.6 | VALID |
| C008-02 | REJECT | False | 2.85 | VALID |
| C009-01 | PASS | True | 4.1 | VALID |
| C009-02 | PASS | True | 3.85 | VALID |
| C009-03 | REJECT | True | 3.25 | VALID |
| C010-01 | PASS | True | 3.75 | VALID |
| C010-02 | PASS | True | 3.75 | VALID |
| C010-03 | REJECT | False | 3.5 | VALID |
| C011-01 | REJECT | False | 2.75 | VALID |
| C011-02 | PASS | True | 3.5 | VALID |
| C011-03 | PASS | True | 4.15 | VALID |
| C011-04 | REJECT | True | 3.35 | VALID |
| C012-01 | PASS | True | 4.25 | VALID |
| C012-02 | PASS | True | 4.25 | VALID |
| C012-03 | PASS | False | 4.5 | VALID |
| C013-01 | PASS | True | 4.25 | VALID |
| C013-02 | PASS | True | 4.5 | VALID |
| C013-03 | REJECT | True | 3.4 | VALID |
| C014-01 | REJECT | True | 3.5 | VALID |
| C014-02 | PASS | False | 4.25 | VALID |
| C015-01 | PASS | True | 4.25 | VALID |
| C015-02 | PASS | True | 4.0 | VALID |
| C015-03 | PASS | False | 4.25 | VALID |
| C016-01 | REJECT | True | 3.25 | VALID |
