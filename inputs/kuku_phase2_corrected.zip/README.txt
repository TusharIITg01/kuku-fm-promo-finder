KUKU FM — FIND THE PROMOS
PHASE 2 CORRECTED DELIVERABLES
Version: 1.0.1

FILES
- generate_candidates.py
- promo_candidates.json
- promo_candidates.csv
- candidate_generation_summary.json
- candidate_generation_validation.json
- aliases.json (small dependency used by the generator)

WHAT CHANGED
1. Candidate `events`, `event_ids`, `candidate_text` and `candidate_text_relative` now contain only events fully contained within the clip window.
2. Any event overlapping a clip boundary without being fully contained is recorded separately in `boundary_events`, with its original ID, timestamps, category, text and boundary relationship. `boundary_event_ids` is retained for compatibility.
3. Lookahead now includes only events from the same episode whose start timestamp is at or after the clip end and before clip end + 15 seconds. Boundary-overlapping events are not repeated in lookahead.
4. Lookahead summary statistics are mutually exclusive: full, partial and none.

PRESERVATION
- Candidate count remains 162.
- All candidate IDs, start/end timestamps, durations and fully-contained `event_ids` remain unchanged.
- Candidate selection / pruning functions were not changed.
- Phase 1 parser code and outputs were not rewritten.

RUN
Use the Phase 1 parsed outputs from the original Phase 1 ZIP:
python generate_candidates.py --parsed-json PATH_TO_PHASE1/parser_output/parsed_episodes.json --events-csv PATH_TO_PHASE1/parser_output/parsed_events.csv --aliases aliases.json --out-dir candidate_output

The script writes promo_candidates.json, promo_candidates.csv, candidate_generation_summary.json and candidate_generation_validation.json.

VALIDATION
The delivered candidate_generation_validation.json includes the separate audit against the original screenplay ZIP and Phase 1 parsed data. The generator itself also writes its own validation results when rerun.

LIMITATIONS
- Timestamps are validated against screenplay text, not rendered video.
- Lookahead event selection uses event start times within the 15-second lookahead start window. Original full event timestamps and text are preserved.
- Phase 1 source anomalies remain warnings (out-of-order blocks, same-track overlaps and the known scene overrun).
- No semantic/LLM evaluation has been performed. Phase 3 has not started.
